git log --pretty=oneline | cut -d" " -f1 | head -5
