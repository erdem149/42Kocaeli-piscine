find . -type file -name '*.sh' -execdir basename {} .sh \;
