#include<unistd.h>
int main()
{
	int i;
	i = 1;
	while(i<=100)
	{
		if(i%3==0)
		{
			write(1,"fizz",4);
			write(1,&"\n",1);
		}
		if(i%5==0)
		{
			write(1, "buzz",4);
			write(1, "\n", 1);
		}
		if(i%3==0&&i%5==0)
		{			
			write(1, "fizzbuzz",8);
			write(1, &"\n",1);
		}
		if(i%3!=0&&i%5!=0)
		{
			int a=i/10;
			int b=i%10;
			int a1=a+'0';
			int b1=b+'0';
			if(a != 0)
			{
				write(1, &a1,1);
			}
			write(1, &b1,1);
			write(1, &"\n",1);
		}	
		i++;
	}
}
